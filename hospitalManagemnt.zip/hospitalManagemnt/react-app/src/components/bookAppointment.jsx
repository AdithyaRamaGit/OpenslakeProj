import React, { useState } from "react";
import { api } from "../api/api";

export default function RegisterHospital() {
  const [hospital, setHospital] = useState({ name: "", location: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post("/hospitals/", hospital);
    alert("Hospital registered!");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Register Hospital</h2>
      <input placeholder="Name" onChange={(e) => setHospital({ ...hospital, name: e.target.value })} />
      <input placeholder="Location" onChange={(e) => setHospital({ ...hospital, location: e.target.value })} />
      <button type="submit">Register</button>
    </form>
  );
}
