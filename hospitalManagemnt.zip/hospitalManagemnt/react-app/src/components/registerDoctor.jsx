import { useState } from 'react';
import { api } from '../api/api';

export default function RegisterDoctor() {
  const [doctor, setDoctor] = useState({
    name: '',
    qualifications: '',
    specializations: '',
    years_experience: 0
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/doctors/', doctor);
      alert('Doctor Registered!');
    } catch (error) {
      console.error(error);
      alert('Error registering doctor.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Register Doctor</h2>
      <input
        placeholder="Name"
        value={doctor.name}
        onChange={(e) => setDoctor({ ...doctor, name: e.target.value })}
      />
      <input
        placeholder="Qualifications"
        value={doctor.qualifications}
        onChange={(e) => setDoctor({ ...doctor, qualifications: e.target.value })}
      />
      <input
        placeholder="Specializations (comma separated)"
        value={doctor.specializations}
        onChange={(e) => setDoctor({ ...doctor, specializations: e.target.value })}
      />
      <input
        type="number"
        placeholder="Years of Experience"
        value={doctor.years_experience}
        onChange={(e) => setDoctor({ ...doctor, years_experience: parseInt(e.target.value) })}
      />
      <button type="submit">Register Doctor</button>
    </form>
  );
}
