import React, { useEffect, useState } from "react";
import { api } from "../api/api";

export default function HospitalDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    async function fetchDashboard() {
      const res = await api.get("/hospitals/1/dashboard"); // adjust ID as needed
      setData(res.data);
    }
    fetchDashboard();
  }, []);

  if (!data) return <p>Loading...</p>;

  return (
    <div>
      <h2>Hospital Dashboard</h2>
      <p>Total Consultations: {data.total_consultations}</p>
      <p>Total Revenue: {data.total_revenue}</p>
      <h3>Revenue per Doctor</h3>
      <ul>
        {data.revenue_per_doctor.map((r) => (
          <li key={r.doctor_id}>{r.doctor_name}: {r.revenue}</li>
        ))}
      </ul>
    </div>
  );
}
