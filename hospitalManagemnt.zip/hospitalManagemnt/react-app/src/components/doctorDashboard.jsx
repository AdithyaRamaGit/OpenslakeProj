import React, { useState, useEffect } from "react";
import { api } from "../api/api";

export default function DoctorDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      const res = await api.get("/doctors/1/dashboard"); // replace with real ID
      setData(res.data);
    };
    loadData();
  }, []);

  if (!data) return <p>Loading...</p>;

  return (
    <div>
      <h2>Doctor Dashboard</h2>
      <p>Total Earnings: ₹{data.total_earnings}</p>
      <p>Total Consultations: {data.total_consultations}</p>
      <h3>Earnings by Hospital:</h3>
      <ul>
        {data.earnings_by_hospital.map((h) => (
          <li key={h.hospital_id}>{h.hospital_name}: ₹{h.earnings}</li>
        ))}
      </ul>
    </div>
  );
}
