import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import RegisterHospital from "./components/registerHospital";
import RegisterDoctor from "./components/registerDoctor";
import RegisterPatient from "./components/registerPatient";
import BookAppointment from "./components/bookAppointment";
import HospitalDashboard from "./components/hospitalDashboard";
import DoctorDashboard from "./components/doctorDashboard";
import PatientHistory from "./components/patientHistory";

function App() {
  return (
    <BrowserRouter>
      <nav>
        <Link to="/register-hospital">Register Hospital</Link> | 
        <Link to="/register-doctor">Register Doctor</Link> | 
        <Link to="/register-patient">Register Patient</Link> | 
        <Link to="/book-appointment">Book Appointment</Link> | 
        <Link to="/hospital-dashboard">Hospital Dashboard</Link> | 
        <Link to="/doctor-dashboard">Doctor Dashboard</Link> | 
        <Link to="/patient-history">Patient History</Link>
      </nav>
      <Routes>
        <Route path="/register-hospital" element={<RegisterHospital />} />
        <Route path="/register-doctor" element={<RegisterDoctor />} />
        <Route path="/register-patient" element={<RegisterPatient />} />
        <Route path="/book-appointment" element={<BookAppointment />} />
        <Route path="/hospital-dashboard" element={<HospitalDashboard />} />
        <Route path="/doctor-dashboard" element={<DoctorDashboard />} />
        <Route path="/patient-history" element={<PatientHistory />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
