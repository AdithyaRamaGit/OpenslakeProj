import React, { useState, useEffect } from "react";
import { api } from "../api/api";

export default function PatientHistory() {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const loadHistory = async () => {
      const res = await api.get("/patients/1/history"); // replace with real ID
      setHistory(res.data);
    };
    loadHistory();
  }, []);

  return (
    <div>
      <h2>Patient History</h2>
      {history.map((rec, idx) => (
        <div key={idx}>
          <p>Doctor: {rec.doctor_name}</p>
          <p>Hospital: {rec.hospital_name}</p>
          <p>Date: {rec.date}</p>
          <p>Amount Paid: ₹{rec.amount}</p>
          <hr/>
        </div>
      ))}
    </div>
  );
}
